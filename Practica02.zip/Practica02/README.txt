Practica 02
REDES DE COMPUTADORAS
MIENMBROS DEL EQUIPO:
César Martín Ortiz Alarcon, 3-06043220-0

Profesor: José Luis Torres Rodríguez
Ayudante de laboratorio: Juan Manuel Rosas Gutiérrez

MODO DE EJECUCION DEL PROGRAMA

Tenemos que estar parados en el directorio del programa "Practica02"

Para compilar se ingresa el comando "make" estando parados sobre la carpeta "Practica02"

/Practica02# make

Para ejecutar el programa estando parados en "Practica02" ingresamos './bin/ftp':

/Practica02# ./bin/ftp

Si por otro lado ingresamos a la carpeta "bin", solo bastaria ejecutar el comando './ftp'

/Practica02/bin# ./ftp 


DETALLE DE VERSIONES UTILIZADAS
Núcleo de Linux: 3.19.0-56-generic
Compilado con: GNU C Compiler (GCC), versión 4.9.2 (Ubuntu 4.9.2-10ubuntu13) 
Plataforma: Ubuntu 15.04 <<Vivid Vervet>> x86 (32 bits)

