/*
 * Servidor de HTTP/1.1
 *
 * Autor: César Martín Ortiz Alarcon
 *3-0604322-0.
 * cesarmartin@ciencias.unam.mx
 */

int main(void)
{
	return 0;
}//main
